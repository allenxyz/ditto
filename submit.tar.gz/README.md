This is for eecs285 group


Collaborators:
	Allen Zhao
	Jessica Wu
	Patrick Wan
	Eleanor Rhode


Project:
	Image processing
	Simulatenous, multi-people editing, white-board-like 
	


ENJOY! :)
	
