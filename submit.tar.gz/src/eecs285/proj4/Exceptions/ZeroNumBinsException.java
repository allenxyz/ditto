package eecs285.proj4.Exceptions;

public class ZeroNumBinsException extends Exception
{
  public ZeroNumBinsException(String message)
  {
    super(message);
  }
}
