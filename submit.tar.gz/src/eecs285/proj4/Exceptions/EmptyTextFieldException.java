package eecs285.proj4.Exceptions;

public class EmptyTextFieldException extends Exception
{
  public EmptyTextFieldException(String message)
  {
    super(message);
  }
}
